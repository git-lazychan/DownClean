============================================================
DownClean - Smart & Minimalist Download Organizer
Platform: Windows (Portable / No Installation)
Thank you for purchasing DownClean!
This tool is built for those who value speed, simplicity,
and a clutter-free Downloads folder.

[HOW TO USE]

Place 'DownClean.exe' on your computer.

Run the application (No installation required).

Click the 'ORGANIZE NOW' button.

Instantly sort messy Downloads into clean categories.

[CORE FEATURES]

Ultra-Lightweight: No installation, no registry changes, no background processes.

Privacy-Centric: Fully offline. Your files never leave your PC.

Modern UI: Designed for a clean, distraction-free experience.

One-Click Workflow: Open → Click → Done.

[WHAT GETS ORGANIZED]

DownClean automatically sorts files such as:

• Images (JPG, PNG, GIF…)

• Videos (MP4, AVI, MOV…)

• Documents (PDF, DOCX…)

• Others (ZIP, RAR…)

Files are moved into clearly named folders.

[ABOUT UNDO]

DownClean intentionally does not include an Undo feature.
This design choice guarantees maximum speed and full privacy.
Files are moved into categorized folders and never deleted.
You remain in full control before execution.

[SAFETY NOTICE]

DownClean never deletes files.
It only moves them into categorized folders.

[ATTRIBUTION]

Icon created by Freepik - Flaticon ()
<a href="https://www.flaticon.com/free-icons/folder" title="folder icons">Folder icons created by Freepik - Flaticon</a>

============================================================
© DownClean Project. All rights reserved.